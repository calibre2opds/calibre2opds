
Here are some simple examples of configuring the colors shown in Calibre2opds HTML catalogs.

To try out one of these, copy the files for the color scheme you want to try out to one of the
following locations:
- The Calibre2opds configuration folder
- The Calibre2opds install folder

Contributed by Wyndham Clampett
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~